# Building GrabWave.exe

This turns the app into a single Windows program — double-click it, browser
opens, no Python install needed for whoever runs it.

**Important: this build step must be run on a Windows PC.** PyInstaller
builds an executable for whatever OS it's running on, so it has to be run
on Windows to produce a `.exe`.

## One-time setup (on your Windows PC, inside the `grabwave` folder)

```powershell
pip install -r requirements.txt
pip install pyinstaller
```

## Build the .exe

```powershell
pyinstaller --onefile --console --name GrabWave --add-data "templates;templates" app.py
```

- `--onefile` → produces a single `GrabWave.exe`, nothing else to ship.
- `--console` → keeps a small terminal window open showing status/progress
  (recommended — closing it stops the server). Use `--windowed` instead if
  you want it fully hidden, but then there's no way to see errors or stop
  it except Task Manager.
- `--add-data "templates;templates"` → bundles `index.html` into the exe.

This creates a `dist` folder. Inside it: `GrabWave.exe`. That single file
is what you share or attach to a GitHub Release.

## ffmpeg still required

The `.exe` bundles Python and your app, but **not ffmpeg** — that's a
separate program yt-dlp calls out to. Whoever runs `GrabWave.exe` still
needs ffmpeg installed and on their PATH (see the main README for the
`winget install Gyan.FFmpeg` command), or you can place `ffmpeg.exe`
directly next to `GrabWave.exe` — yt-dlp will find it there too.

If you want the exe to be fully self-contained (ffmpeg included, no
separate install step for users), download the ffmpeg build's `ffmpeg.exe`
yourself and place it in the same `dist` folder as `GrabWave.exe` before
zipping/sharing them together.

## Testing it

Double-click `dist\GrabWave.exe`. A console window opens, and your browser
should launch automatically to `http://127.0.0.1:5000`. Close the console
window to stop the app.

## Distributing it

- Zip `GrabWave.exe` (and `ffmpeg.exe` if you included it) into one file,
  e.g. `GrabWave-Windows.zip`.
- Attach that zip to a GitHub Release on your repo (Releases → Create a new
  release → upload the zip). This is the "public download" people click —
  they get the zip, extract it, double-click `GrabWave.exe`, and it runs
  entirely on their own machine.
