"""
GrabWave - a local YouTube (and yt-dlp supported) video/audio downloader.

Backend: Flask + yt-dlp + ffmpeg.
Run:  python app.py   then open http://127.0.0.1:5000

Only download content you own or have the right to download.
"""

import os
import sys
import glob
import time
import uuid
import shutil
import threading
import webbrowser

from flask import Flask, request, jsonify, send_file, render_template
import yt_dlp

# When PyInstaller bundles this into an .exe, templates/ get extracted to a
# temp folder at sys._MEIPASS. When run as a normal script, use this file's
# own folder. Either way Flask needs the right template_folder.
if getattr(sys, "frozen", False):
    BASE_DIR = sys._MEIPASS
    APP_DIR = os.path.dirname(sys.executable)  # folder the .exe lives in
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    APP_DIR = BASE_DIR

app = Flask(__name__, template_folder=os.path.join(BASE_DIR, "templates"))

# Downloads are staged next to the .exe (or app.py), never inside the
# temp bundle folder, so they survive after the process exits.
DOWNLOADS_DIR = os.path.join(APP_DIR, "downloads")
os.makedirs(DOWNLOADS_DIR, exist_ok=True)

MP4_QUALITIES = {"best", "2160", "1440", "1080", "720", "480", "360"}
MP3_QUALITIES = {"320", "256", "192", "128"}

# Staged job folders older than this (seconds) are purged on the next request.
MAX_STAGE_AGE = 3600


def purge_old_jobs():
    """Remove stale staged download folders so the disk doesn't fill up."""
    now = time.time()
    for name in os.listdir(DOWNLOADS_DIR):
        path = os.path.join(DOWNLOADS_DIR, name)
        try:
            if os.path.isdir(path) and now - os.path.getmtime(path) > MAX_STAGE_AGE:
                shutil.rmtree(path, ignore_errors=True)
        except OSError:
            pass


def build_opts(outtmpl, kind, quality):
    """Build yt-dlp options for an mp4 (video) or mp3 (audio) job."""
    opts = {
        "outtmpl": outtmpl,
        "restrictfilenames": True,   # safe ASCII filenames on every OS
        "noplaylist": True,          # one video, even from a playlist URL
        "quiet": True,
        "no_warnings": True,
        "ignoreerrors": False,
    }

    if kind == "mp3":
        q = quality if quality in MP3_QUALITIES else "192"
        opts["format"] = "bestaudio/best"
        opts["postprocessors"] = [{
            "key": "FFmpegExtractAudio",
            "preferredcodec": "mp3",
            "preferredquality": q,
        }]
    else:  # mp4
        if quality == "best" or quality not in MP4_QUALITIES:
            fmt = "bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio/best"
        else:
            fmt = (
                f"bestvideo[height<={quality}][ext=mp4]+bestaudio[ext=m4a]/"
                f"bestvideo[height<={quality}]+bestaudio/"
                f"best[height<={quality}]/best"
            )
        opts["format"] = fmt
        opts["merge_output_format"] = "mp4"

    return opts


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/info", methods=["POST"])
def info():
    """Fetch metadata (title, thumbnail, available resolutions) without downloading."""
    data = request.get_json(silent=True) or {}
    url = (data.get("url") or "").strip()
    if not url:
        return jsonify({"error": "Paste a video link first."}), 400

    try:
        with yt_dlp.YoutubeDL({"quiet": True, "no_warnings": True, "noplaylist": True}) as ydl:
            meta = ydl.extract_info(url, download=False)
    except Exception as e:
        return jsonify({"error": f"Couldn't read that link. {str(e)[:180]}"}), 400

    heights = sorted(
        {f.get("height") for f in meta.get("formats", []) if f.get("height")},
        reverse=True,
    )
    return jsonify({
        "title": meta.get("title"),
        "uploader": meta.get("uploader") or meta.get("channel"),
        "duration": meta.get("duration"),
        "thumbnail": meta.get("thumbnail"),
        "heights": heights,
    })


@app.route("/api/download", methods=["POST"])
def download():
    """Download + transcode, then stream the finished file back to the browser."""
    purge_old_jobs()

    data = request.get_json(silent=True) or {}
    url = (data.get("url") or "").strip()
    kind = (data.get("type") or "mp4").lower()
    quality = str(data.get("quality") or "best")

    if not url:
        return jsonify({"error": "Paste a video link first."}), 400
    if kind not in ("mp4", "mp3"):
        return jsonify({"error": "Type must be mp4 or mp3."}), 400

    job_dir = os.path.join(DOWNLOADS_DIR, uuid.uuid4().hex[:12])
    os.makedirs(job_dir, exist_ok=True)
    outtmpl = os.path.join(job_dir, "%(title)s.%(ext)s")

    try:
        with yt_dlp.YoutubeDL(build_opts(outtmpl, kind, quality)) as ydl:
            ydl.download([url])
    except Exception as e:
        shutil.rmtree(job_dir, ignore_errors=True)
        return jsonify({"error": f"Download failed. {str(e)[:180]}"}), 500

    files = [f for f in glob.glob(os.path.join(job_dir, "*")) if os.path.isfile(f)]
    if not files:
        shutil.rmtree(job_dir, ignore_errors=True)
        return jsonify({"error": "No output file was produced."}), 500

    # After merging/transcoding the final file is the largest one in the folder.
    filepath = max(files, key=os.path.getsize)
    mimetype = "audio/mpeg" if kind == "mp3" else "video/mp4"

    return send_file(
        filepath,
        as_attachment=True,
        download_name=os.path.basename(filepath),
        mimetype=mimetype,
    )


def open_browser():
    # Give the server a moment to start before the browser tries to connect.
    time.sleep(1.2)
    webbrowser.open("http://127.0.0.1:5000")


if __name__ == "__main__":
    print("GrabWave running at http://127.0.0.1:5000")
    print("Opening your browser... (keep this window open while using the app)")
    threading.Thread(target=open_browser, daemon=True).start()
    app.run(host="127.0.0.1", port=5000, debug=False, threaded=True)
