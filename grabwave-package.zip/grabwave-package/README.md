# GrabWave

A small local web app to download video (MP4) or audio (MP3) at the highest
available quality. Python/Flask backend driving `yt-dlp` + `ffmpeg`, with a
single-page browser UI.

## What it does
- Paste a link, preview the title/thumbnail/duration before committing.
- **MP4** — picks the best video + best audio at your chosen resolution and
  merges them into one `.mp4` (best, 4K, 1440p, 1080p, 720p, 480p, 360p).
- **MP3** — extracts audio and converts to MP3 at 128–320 kbps.
- Live progress bar; files save through your browser's normal download flow.

## Requirements
- **Python 3.8+**
- **ffmpeg** — required for MP3 conversion and for merging high-res MP4
  (above 720p, video and audio come as separate streams that must be merged).

### Install ffmpeg
- **Windows:** `winget install Gyan.FFmpeg` (or download from ffmpeg.org and add it to PATH)
- **macOS:** `brew install ffmpeg`
- **Ubuntu/Debian:** `sudo apt install ffmpeg`

## Setup
```bash
cd grabwave
python -m venv venv
# Windows:  venv\Scripts\activate
# macOS/Linux:  source venv/bin/activate
pip install -r requirements.txt
python app.py
```
Then open <http://127.0.0.1:5000> in your browser.

## Notes
- Finished files are briefly staged in `downloads/` on the server side, then
  streamed to your browser. Staged folders older than an hour are auto-cleaned
  on the next request.
- `yt-dlp` is updated often to keep up with site changes. If a download starts
  failing, update it first: `pip install -U yt-dlp`.
- It works with many sites yt-dlp supports, not only YouTube.

## A note on usage
Downloading can conflict with a site's Terms of Service. Use this only for
content you own, that's under a permissive license, or that you otherwise have
the right to download.
